
# from django import forms
# from .models import Picture, Address, Question
#
# class GalleryForm(forms.Form):
#     image = forms.ImageField()
#
# class AddressForm(forms.ModelForm):
#     class Meta:
#         model = Address
#         fields = '__all__'
#
# class QuestionForm(forms.ModelForm):
#     class Meta:
#         model = Question
#         fields = '__all__'
